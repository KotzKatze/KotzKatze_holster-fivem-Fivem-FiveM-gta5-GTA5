script by:
KotzKatze
it's a simple weapon holster script
with /waffe you can put your weapon back in the trunk :)!